﻿# PrivacyScreen iOS 管理端

这是 iPhone/iPad 上的**管理端**，不是被控端。

iOS 系统限制决定了 iOS 不能做被控端：
- 不能后台常驻
- 不能开机自启
- 不能拦截 Win 键
- 不能远程关机/重启
- 不能隐藏进程

所以 iOS 只做：设备列表、在线状态、锁定/解除、发消息、自定义文字、关机/重启、删除设备。

## 已内置

- 中继地址：`ws://114.66.41.109:10009`
- Console token：已写在 `PrivacyConsole/ContentView.swift`
- 操作员：`iPhone`
- 打开 App 自动连接

如果轮换了 token，修改 `ContentView.swift` 里的 URL 重新构建。

## 用 GitHub Actions 生成未签名 IPA

1. 新建一个 GitHub 仓库
2. 把项目里的 `ios/` 和 `.github/workflows/ios.yml` 上传到仓库
3. 打开仓库 **Actions**
4. 选择 **Build iOS IPA** → **Run workflow**
5. 构建完成后下载 artifact：`PrivacyConsole-unsigned-ipa`
6. 解压得到 `PrivacyConsole-unsigned.ipa`
7. 用 Sideloadly / AltStore / Esign 等工具自签安装

免费 Apple ID 自签通常 7 天过期，过期后重新签一次。付费开发者账号是 1 年。

## 本地 Xcode 构建

需要 macOS + Xcode：

```bash
brew install xcodegen
cd ios
xcodegen generate
open PrivacyConsole.xcodeproj
```

在 Xcode 里设置你的 Team 和 Bundle Identifier，然后真机运行。

## 未签名 IPA 说明

GitHub Actions 里的构建命令是：

```bash
xcodebuild ... CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO
```

产物是未签名 `.app`，再打包成：

```text
Payload/PrivacyConsole.app
```

自签工具会对它重新签名。Bundle Identifier 当前是：

```text
com.chagee.privacyscreen.console
```

如果自签工具要求唯一 ID，改成你自己的。

## 测试地址

当前 App 使用：

```text
ws://114.66.41.109:10009
```

已在 `Info.plist` 里允许 `ws://`（NSAllowsArbitraryLoads）。正式环境建议有域名后改成 `wss://`，并去掉 ATS 例外。