import Foundation
import SwiftUI
import Combine

enum Theme {
    static let bg = Color(red: 7/255, green: 11/255, blue: 18/255)
    static let surface = Color(red: 16/255, green: 25/255, blue: 38/255)
    static let surface2 = Color(red: 22/255, green: 33/255, blue: 49/255)
    static let border = Color(red: 34/255, green: 48/255, blue: 66/255)
    static let text = Color(red: 232/255, green: 240/255, blue: 250/255)
    static let muted = Color(red: 139/255, green: 158/255, blue: 184/255)
    static let accent = Color(red: 45/255, green: 212/255, blue: 150/255)
    static let danger = Color(red: 248/255, green: 113/255, blue: 113/255)
    static let warning = Color(red: 251/255, green: 191/255, blue: 36/255)
}

enum PowerAction: String, Identifiable, Equatable {
    case shutdown
    case reboot
    var id: String { rawValue }
}

struct ContentView: View {
    @StateObject private var relay = RelayClient(
        url: URL(string: "ws://114.66.41.109:10009/console?token=83aac3c5499dbe6738987912412b76f65aa03442c0a6967a&operator=iPhone")!
    )
    @Environment(\.scenePhase) private var scenePhase

    private let reconnectTimer = Timer.publish(every: 10, on: .main, in: .common).autoconnect()

    @State private var selectedId: String?
    @State private var searchText = ""
    @State private var showMessage = false
    @State private var messageText = ""
    @State private var showTextEditor = false
    @State private var badgeText = "● 设备管控中"
    @State private var titleText = "茶姬科技 设备强制管控"
    @State private var subText = "如需协助，请联系 IT 服务台"
    @State private var pendingPower: PowerAction?
    @State private var showRestartConfirm = false
    @State private var showUninstallConfirm = false
    @State private var showDeleteConfirm = false

    private var selectedSet: Set<String> {
        guard let selectedId = selectedId else { return [] }
        return [selectedId]
    }

    private var selectedDevice: Device? {
        relay.devices.first { $0.id == selectedId }
    }

    private var filteredDevices: [Device] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if query.isEmpty { return relay.devices }
        return relay.devices.filter {
            $0.deviceId.lowercased().contains(query)
                || $0.hostname.lowercased().contains(query)
                || $0.user.lowercased().contains(query)
        }
    }

    private var onlineCount: Int {
        relay.devices.filter { $0.online }.count
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.bg.ignoresSafeArea()
                RadialGradient(
                    colors: [Theme.accent.opacity(0.13), .clear],
                    center: .topLeading,
                    startRadius: 0,
                    endRadius: 560
                )
                .ignoresSafeArea()

                VStack(spacing: 0) {
                    header
                    searchBar
                    deviceList
                    actionBar
                }
            }
            .navigationBarHidden(true)
            .preferredColorScheme(.dark)
            .onAppear { relay.connect() }
            .onChange(of: scenePhase) { phase in
                if phase == .active { relay.connect() }
            }
            .onReceive(reconnectTimer) { _ in
                if !relay.connected { relay.connect() }
            }
            .alert("下发消息", isPresented: $showMessage) {
                TextField("消息内容", text: $messageText)
                Button("发送") {
                    relay.sendCommand(deviceIds: selectedSet, action: "message", payload: ["text": messageText])
                    messageText = ""
                }
                Button("取消", role: .cancel) { messageText = "" }
            }
            .alert("重启 Agent", isPresented: $showRestartConfirm) {
                Button("确认重启", role: .destructive) {
                    relay.sendCommand(deviceIds: selectedSet, action: "restart_agent")
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("Agent 会退出并由守护进程重新拉起。")
            }
            .alert("远程卸载", isPresented: $showUninstallConfirm) {
                Button("确认卸载", role: .destructive) {
                    relay.sendCommand(deviceIds: selectedSet, action: "uninstall", payload: ["confirm": true])
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("会停止并移除被控端 Agent，设备随后变为离线。")
            }
            .alert("删除设备", isPresented: $showDeleteConfirm) {
                Button("删除", role: .destructive) {
                    relay.forget(deviceIds: selectedSet)
                    selectedId = nil
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("只删除离线设备；在线设备请先卸载 Agent。")
            }
            .confirmationDialog(
                "确认操作",
                isPresented: Binding(
                    get: { pendingPower != nil },
                    set: { if !$0 { pendingPower = nil } }
                ),
                presenting: pendingPower
            ) { action in
                Button(action == .shutdown ? "确认关机" : "确认重启", role: .destructive) {
                    relay.sendCommand(deviceIds: selectedSet, action: action.rawValue, payload: ["confirm": true])
                    pendingPower = nil
                }
                Button("取消", role: .cancel) { pendingPower = nil }
            } message: { action in
                Text(action == .shutdown ? "会强制关闭未保存程序。" : "会强制关闭程序并重启。")
            }
            .sheet(isPresented: $showTextEditor) {
                NavigationStack {
                    Form {
                        Section("遮罩文字") {
                            TextField("徽标文字", text: $badgeText)
                            TextField("主标题", text: $titleText)
                            TextField("副标题（可留空）", text: $subText)
                        }
                        Section {
                            Button("下发到选中设备") {
                                relay.sendCommand(
                                    deviceIds: selectedSet,
                                    action: "set_config",
                                    payload: [
                                        "badgeText": badgeText,
                                        "titleText": titleText,
                                        "subText": subText
                                    ]
                                )
                                showTextEditor = false
                            }
                            .disabled(selectedId == nil)
                        }
                    }
                    .scrollContentBackground(.hidden)
                    .background(Theme.bg)
                    .navigationTitle("自定义文字")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("关闭") { showTextEditor = false }
                        }
                    }
                }
                .preferredColorScheme(.dark)
            }
        }
    }

    private var header: some View {
        HStack(alignment: .center, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text("PRIVACYSCREEN")
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .tracking(2)
                    .foregroundStyle(Theme.accent)
                Text("终端管控中心")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .foregroundStyle(Theme.text)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 6) {
                HStack(spacing: 6) {
                    Circle()
                        .fill(relay.connected ? Theme.accent : Theme.danger)
                        .frame(width: 7, height: 7)
                    Text(relay.connected ? "已连接" : "未连接")
                        .font(.caption2)
                        .foregroundStyle(Theme.muted)
                }
                Text("\(onlineCount) 在线")
                    .font(.caption2)
                    .foregroundStyle(Theme.muted)
            }
            Button {
                relay.connect()
            } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.text)
                    .frame(width: 34, height: 34)
                    .background(Circle().fill(Theme.surface2))
                    .overlay(Circle().stroke(Theme.border, lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 20)
        .padding(.top, 10)
        .padding(.bottom, 14)
    }

    private var searchBar: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Theme.muted)
            TextField("搜索设备码 / 主机名", text: $searchText)
                .textFieldStyle(.plain)
                .foregroundStyle(Theme.text)
                .autocorrectionDisabled()
            if !searchText.isEmpty {
                Button {
                    searchText = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(Theme.muted)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(RoundedRectangle(cornerRadius: 14).fill(Theme.surface))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Theme.border, lineWidth: 1))
        .padding(.horizontal, 20)
    }

    private var deviceList: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                if filteredDevices.isEmpty {
                    VStack(spacing: 10) {
                        Image(systemName: "desktopcomputer")
                            .font(.system(size: 34, weight: .light))
                            .foregroundStyle(Theme.muted)
                        Text(relay.devices.isEmpty ? "暂无设备" : "没有匹配的设备")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(Theme.muted)
                        if relay.devices.isEmpty {
                            Text("请在目标电脑运行被控端")
                                .font(.caption)
                                .foregroundStyle(Theme.muted)
                        }
                    }
                    .padding(.top, 80)
                } else {
                    ForEach(filteredDevices) { device in
                        DeviceCard(device: device, selected: selectedId == device.id)
                            .onTapGesture { selectedId = device.id }
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 14)
        }
    }

    private var actionBar: some View {
        VStack(spacing: 6) {
            Text(relay.log)
                .font(.caption2)
                .foregroundStyle(Theme.muted)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 20)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    actionChip("锁定", "lock.fill", Theme.accent) {
                        relay.sendCommand(deviceIds: selectedSet, action: "lock")
                    }
                    actionChip("解除", "lock.open.fill", Theme.muted) {
                        relay.sendCommand(deviceIds: selectedSet, action: "unlock")
                    }
                    actionChip("消息", "text.bubble", Theme.muted) {
                        showMessage = true
                    }
                    actionChip("文字", "character.cursor.ibeam", Theme.muted) {
                        if let device = selectedDevice {
                            if !device.badgeText.isEmpty { badgeText = device.badgeText }
                            if !device.titleText.isEmpty { titleText = device.titleText }
                            subText = device.subText
                        }
                        showTextEditor = true
                    }
                    actionChip("刷新", "arrow.clockwise.circle", Theme.muted) {
                        relay.sendCommand(deviceIds: selectedSet, action: "status")
                    }
                    actionChip("重启", "arrow.triangle.2.circlepath", Theme.muted) {
                        showRestartConfirm = true
                    }
                    actionChip("卸载", "trash.slash", Theme.danger) {
                        showUninstallConfirm = true
                    }
                    actionChip("关机", "power", Theme.danger) {
                        pendingPower = .shutdown
                    }
                    actionChip("重启电脑", "restart", Theme.danger) {
                        pendingPower = .reboot
                    }
                    actionChip("删除", "trash", Theme.muted) {
                        showDeleteConfirm = true
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 10)
            }
        }
        .padding(.top, 8)
        .background(.ultraThinMaterial)
    }

    private func actionChip(_ title: String, _ icon: String, _ tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .semibold))
                Text(title)
                    .font(.system(size: 12, weight: .semibold))
            }
            .foregroundStyle(tint)
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .background(Capsule().fill(tint.opacity(0.13)))
            .overlay(Capsule().stroke(tint.opacity(0.32), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .disabled(selectedId == nil)
        .opacity(selectedId == nil ? 0.4 : 1)
    }
}

struct DeviceCard: View {
    let device: Device
    let selected: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(device.deviceId)
                    .font(.system(size: 16, weight: .bold, design: .monospaced))
                    .foregroundStyle(Theme.text)
                Spacer()
                statusPill
            }

            Text(device.hostname)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Theme.text)
                .lineLimit(1)

            HStack(spacing: 6) {
                Text(device.user)
                Text("·")
                Text(device.os)
            }
            .font(.caption)
            .foregroundStyle(Theme.muted)
            .lineLimit(1)

            HStack {
                Text(device.locked ? "已锁定" : "未锁定")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(device.locked ? Theme.warning : Theme.muted)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Capsule().fill((device.locked ? Theme.warning : Theme.muted).opacity(0.12)))
                    .overlay(Capsule().stroke((device.locked ? Theme.warning : Theme.muted).opacity(0.3), lineWidth: 1))
                Spacer()
                Text(device.lastSeen.isEmpty ? "" : "心跳 \(device.lastSeen)")
                    .font(.caption2)
                    .foregroundStyle(Theme.muted)
                    .lineLimit(1)
            }
        }
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 18).fill(Theme.surface))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(selected ? Theme.accent : Theme.border, lineWidth: selected ? 1.6 : 1)
        )
        .shadow(color: Color.black.opacity(0.18), radius: 10, y: 4)
        .contentShape(RoundedRectangle(cornerRadius: 18))
    }

    private var statusPill: some View {
        HStack(spacing: 5) {
            Circle()
                .fill(device.online ? Theme.accent : Theme.danger)
                .frame(width: 6, height: 6)
            Text(device.online ? "在线" : "离线")
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(device.online ? Theme.accent : Theme.danger)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(Capsule().fill((device.online ? Theme.accent : Theme.danger).opacity(0.12)))
        .overlay(Capsule().stroke((device.online ? Theme.accent : Theme.danger).opacity(0.3), lineWidth: 1))
    }
}