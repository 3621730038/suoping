import SwiftUI

enum PowerAction: String, Identifiable {
    case shutdown
    case reboot
    var id: String { rawValue }
}

struct ContentView: View {
    @StateObject private var relay = RelayClient(
        url: URL(string: "ws://114.66.41.109:10009/console?token=83aac3c5499dbe6738987912412b76f65aa03442c0a6967a&operator=iPhone")!
    )
    @Environment(\.scenePhase) private var scenePhase

    @State private var selectedId: String?
    @State private var showMessage = false
    @State private var messageText = ""
    @State private var showTextEditor = false
    @State private var badgeText = "● 设备管控中"
    @State private var titleText = "茶姬科技 设备强制管控"
    @State private var subText = "如需协助，请联系 IT 服务台"
    @State private var pendingPower: PowerAction?
    @State private var showDeleteConfirm = false

    private var selectedSet: Set<String> {
        guard let selectedId = selectedId else { return [] }
        return [selectedId]
    }

    private var selectedDevice: Device? {
        relay.devices.first { $0.id == selectedId }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if relay.devices.isEmpty {
                    Spacer()
                    Text("暂无设备")
                        .foregroundStyle(.secondary)
                    Spacer()
                } else {
                    List {
                        ForEach(relay.devices) { device in
                            DeviceRow(device: device)
                                .contentShape(Rectangle())
                                .onTapGesture { selectedId = device.id }
                                .listRowBackground(selectedId == device.id ? Color.accentColor.opacity(0.18) : Color.clear)
                        }
                    }
                    .listStyle(.plain)
                }

                Divider()
                controls
                Divider()
                Text(relay.log)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(.bar)
            }
            .navigationTitle("PrivacyScreen 管理端")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack(spacing: 5) {
                        Circle()
                            .fill(relay.connected ? Color.green : Color.red)
                            .frame(width: 8, height: 8)
                        Text(relay.connected ? "在线" : "离线")
                            .font(.caption)
                    }
                }
            }
            .onAppear { relay.connect() }
            .onChange(of: scenePhase) { phase in
                if phase == .active {
                    relay.connect()
                }
            }
            .alert("下发消息", isPresented: $showMessage) {
                TextField("消息内容", text: $messageText)
                Button("发送") {
                    relay.sendCommand(deviceIds: selectedSet, action: "message", payload: ["text": messageText])
                    messageText = ""
                }
                Button("取消", role: .cancel) { messageText = "" }
            }
            .alert("删除设备", isPresented: $showDeleteConfirm) {
                Button("删除", role: .destructive) {
                    relay.forget(deviceIds: selectedSet)
                    selectedId = nil
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("只删除离线设备；在线设备请先卸载 Agent。")
            }
            .confirmationDialog(
                "确认操作",
                isPresented: Binding(
                    get: { pendingPower != nil },
                    set: { if !$0 { pendingPower = nil } }
                ),
                presenting: pendingPower
            ) { action in
                Button(action == .shutdown ? "确认关机" : "确认重启", role: .destructive) {
                    relay.sendCommand(deviceIds: selectedSet, action: action.rawValue, payload: ["confirm": true])
                    pendingPower = nil
                }
                Button("取消", role: .cancel) { pendingPower = nil }
            } message: { action in
                Text(action == .shutdown ? "会强制关闭未保存程序。" : "会强制关闭程序并重启。")
            }
            .sheet(isPresented: $showTextEditor) {
                NavigationStack {
                    Form {
                        Section("遮罩文字") {
                            TextField("徽标文字", text: $badgeText)
                            TextField("主标题", text: $titleText)
                            TextField("副标题（可留空）", text: $subText)
                        }
                        Section {
                            Button("下发到选中设备") {
                                relay.sendCommand(
                                    deviceIds: selectedSet,
                                    action: "set_config",
                                    payload: [
                                        "badgeText": badgeText,
                                        "titleText": titleText,
                                        "subText": subText
                                    ]
                                )
                                showTextEditor = false
                            }
                            .disabled(selectedId == nil)
                        }
                    }
                    .navigationTitle("自定义文字")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("关闭") { showTextEditor = false }
                        }
                    }
                }
            }
        }
    }

    private var controls: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                actionButton("锁定", systemImage: "lock.fill") {
                    relay.sendCommand(deviceIds: selectedSet, action: "lock")
                }
                actionButton("解除", systemImage: "lock.open.fill") {
                    relay.sendCommand(deviceIds: selectedSet, action: "unlock")
                }
                actionButton("发消息", systemImage: "text.bubble") {
                    showMessage = true
                }
                actionButton("自定义文字", systemImage: "character.cursor.ibeam") {
                    if let device = selectedDevice {
                        if !device.badgeText.isEmpty { badgeText = device.badgeText }
                        if !device.titleText.isEmpty { titleText = device.titleText }
                        subText = device.subText
                    }
                    showTextEditor = true
                }
                actionButton("关机", systemImage: "power") {
                    pendingPower = .shutdown
                }
                actionButton("重启", systemImage: "arrow.clockwise") {
                    pendingPower = .reboot
                }
                actionButton("删除设备", systemImage: "trash") {
                    showDeleteConfirm = true
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
        }
    }

    private func actionButton(_ title: String, systemImage: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: systemImage)
                .font(.caption)
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
        }
        .buttonStyle(.bordered)
        .disabled(selectedId == nil)
    }
}

struct DeviceRow: View {
    let device: Device

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(device.deviceId)
                    .font(.headline)
                    .monospaced()
                Spacer()
                Text(device.online ? "在线" : "离线")
                    .font(.caption)
                    .foregroundStyle(device.online ? Color.green : Color.red)
            }
            Text(device.hostname)
                .font(.subheadline)
            HStack(spacing: 8) {
                Text(device.user)
                Text(device.os)
                if device.locked {
                    Text("已锁定")
                        .foregroundStyle(.orange)
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }
}