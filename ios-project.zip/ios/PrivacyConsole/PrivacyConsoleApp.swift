import SwiftUI

@main
struct PrivacyConsoleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}