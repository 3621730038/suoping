import Foundation
import Combine

struct Device: Identifiable, Equatable {
    let deviceId: String
    var hostname: String
    var user: String
    var os: String
    var version: String
    var ip: String
    var online: Bool
    var locked: Bool
    var lastSeen: String
    var badgeText: String
    var titleText: String
    var subText: String

    var id: String { deviceId }

    init?(dict: [String: Any]) {
        guard let deviceId = dict["deviceId"] as? String, !deviceId.isEmpty else { return nil }
        self.deviceId = deviceId
        self.hostname = dict["hostname"] as? String ?? ""
        self.user = dict["user"] as? String ?? ""
        self.os = dict["os"] as? String ?? ""
        self.version = dict["version"] as? String ?? ""
        self.ip = dict["ip"] as? String ?? ""
        self.online = dict["online"] as? Bool ?? false
        self.lastSeen = dict["lastSeen"] as? String ?? ""
        let state = dict["state"] as? [String: Any] ?? [:]
        self.locked = state["locked"] as? Bool ?? false
        self.badgeText = state["badgeText"] as? String ?? ""
        self.titleText = state["titleText"] as? String ?? ""
        self.subText = state["subText"] as? String ?? ""
    }
}

@MainActor
final class RelayClient: ObservableObject {
    @Published var devices: [Device] = []
    @Published var connected = false
    @Published var log = "未连接"

    private let url: URL
    private var task: URLSessionWebSocketTask?
    private var session: URLSession?

    init(url: URL) {
        self.url = url
    }

    func connect() {
        disconnect()
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration)
        self.session = session
        let task = session.webSocketTask(with: url)
        self.task = task
        task.resume()
        log = "连接中…"
        receive()
    }

    func disconnect() {
        task?.cancel(with: .goingAway, reason: nil)
        task = nil
        session?.invalidateAndCancel()
        session = nil
        connected = false
    }

    private func receive() {
        task?.receive { [weak self] result in
            Task { @MainActor in
                guard let self = self else { return }
                switch result {
                case .failure(let error):
                    self.connected = false
                    self.log = "断开：\(error.localizedDescription)"
                case .success(let message):
                    switch message {
                    case .string(let text):
                        self.handle(text)
                    case .data(let data):
                        self.handle(String(data: data, encoding: .utf8) ?? "")
                    @unknown default:
                        break
                    }
                    self.receive()
                }
            }
        }
    }

    private func handle(_ text: String) {
        guard let data = text.data(using: .utf8),
              let raw = try? JSONSerialization.jsonObject(with: data),
              let obj = raw as? [String: Any],
              let type = obj["type"] as? String
        else { return }

        switch type {
        case "hello_ack":
            connected = true
            log = "已连接中继"

        case "device_list":
            let list = obj["devices"] as? [[String: Any]] ?? []
            devices = list.compactMap { Device(dict: $0) }.sorted { lhs, rhs in
                if lhs.online != rhs.online { return lhs.online && !rhs.online }
                return lhs.deviceId < rhs.deviceId
            }

        case "device_update":
            if let dict = obj["device"] as? [String: Any], let device = Device(dict: dict) {
                upsert(device)
            }

        case "device_removed":
            if let id = obj["deviceId"] as? String {
                devices.removeAll { $0.deviceId == id }
            }

        case "command_result":
            let ok = obj["ok"] as? Bool ?? false
            let action = obj["action"] as? String ?? ""
            let message = obj["message"] as? String ?? ""
            log = "\(action) \(ok ? "成功" : "失败") \(message)"

        case "forget_result":
            log = "删除设备：\(obj["message"] as? String ?? "")"

        case "error":
            log = "错误：\(obj["message"] as? String ?? "")"

        default:
            break
        }
    }

    private func upsert(_ device: Device) {
        if let index = devices.firstIndex(where: { $0.deviceId == device.deviceId }) {
            devices[index] = device
        } else {
            devices.append(device)
        }
        devices.sort { lhs, rhs in
            if lhs.online != rhs.online { return lhs.online && !rhs.online }
            return lhs.deviceId < rhs.deviceId
        }
    }

    func sendCommand(deviceIds: Set<String>, action: String, payload: [String: Any] = [:]) {
        for deviceId in deviceIds {
            let commandId = UUID().uuidString
            send([
                "type": "command",
                "id": commandId,
                "deviceId": deviceId,
                "action": action,
                "payload": payload
            ])
        }
    }

    func forget(deviceIds: Set<String>) {
        for deviceId in deviceIds {
            send(["type": "forget_device", "deviceId": deviceId])
        }
    }

    private func send(_ object: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: object),
              let text = String(data: data, encoding: .utf8)
        else { return }
        task?.send(.string(text)) { [weak self] error in
            guard let error = error else { return }
            Task { @MainActor in
                self?.log = "发送失败：\(error.localizedDescription)"
            }
        }
    }
}